COMPILAR:
	en consola ejecutar:
		-make
		-make run

	*para compilar es necesario tener instalado ant
	*se ocupo java.swift para la interfaz gráfica
	*se ocupo la librería AbsoluteLayout, la cual se encuentra incluída en el archivo

Integrantes:
Jorge Contreras 201573547-6
David Medel 201573548-4
