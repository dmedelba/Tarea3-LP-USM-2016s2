package ventanas;


import ventanas.Sansano;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dmede_000
 */
public class Carrete extends Carta{
    int curacion;
    
    /******** Funcion: carretear ********************
    Descripcion: cura al jugador objetivo, actualizandole la prioridad
    Parametros:
    Sansano Objetivo
    Retorno: void
    ************************************************/
    public void carretear(Sansano Objetivo){
        int currentPrioridad = Objetivo.getPriori();
        currentPrioridad = curacion + currentPrioridad;
        Objetivo.setPriori(currentPrioridad);        
    }
    
    /**** Getter and setter ****/
    
    /******** Funcion: setCuracion ********************
    Descripcion: le asigna el valor de curacion a la carta
    Parametros:
    int cura
    Retorno: void
    ************************************************/
    public void setCuracion(int cura){
        curacion=cura;
    }
    
    /******** Funcion: getCuracion ********************
    Descripcion: obtiene el valor de curacion de la carta
    Parametros:
    Retorno: int, el valor de curacion de la carta
    ************************************************/
    public int getCuracion(){
        return curacion;
    }
    
    
    @Override
    /******** Funcion: Activar ********************
    Descripcion: activa la carta, es decir, ejecuta su efecto(llamando a carretear)
    Parametros:
    Sansano Objetivo
    Retorno: void
    ************************************************/
    public void Activar(Sansano Objetivo){
        carretear(Objetivo);
        //actualizar interfaz  
    }
    
    
    @Override
    /******** Funcion: Activar ********************
    Descripcion: activa la carta, es decir, ejecuta su efecto(llamando a carretear).
    *            Hace exactamente lo mismo que la anterior, no tiene mayor efecto
    Parametros:
    Sansano Objetivo, int marca
    Retorno: void
    ************************************************/
    public void Activar(Sansano Objetivo, int marca){
        carretear(Objetivo);
    }
    
}
