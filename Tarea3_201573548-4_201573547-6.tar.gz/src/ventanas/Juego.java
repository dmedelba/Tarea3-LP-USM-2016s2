package ventanas;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//import ventanas.Unjugador2;
//import ventanas.interfaz;

/**
 *
 * @author dmede_000
 */
public class Juego {

    /**
     * @param args the command line arguments
     */
    
    /******** Funcion: main ********************
    Descripcion: inicia el juego
    Parametros:
    String args[]
    Retorno: void
    ************************************************/
    public static void main(String[] args) {
        new interfaz().setVisible(true);
        

    }
    
}
