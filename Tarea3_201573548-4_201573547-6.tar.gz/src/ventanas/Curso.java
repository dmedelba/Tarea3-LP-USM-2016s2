package ventanas;


import ventanas.Sansano;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dmede_000
 */
class Curso extends Carta{
    int ataque;
    int defensa;
    
    /******** Funcion: aprobar ********************
    Descripcion: aumenta la prioridad del jugador objetivo, segun el valor de defensa de la carta
    Parametros:
    Sansano Jugador
    Retorno: void
    ************************************************/
    public void aprobar(Sansano Jugador){
        int currentPrioridad = Jugador.getPriori();
        currentPrioridad= currentPrioridad+defensa; 
        Jugador.setPriori(currentPrioridad);
    }
    
    /******** Funcion: reprobar ********************
    Descripcion: reduce la prioridad del jugador objetivo, segun el valor de ataque de la carta
    Parametros:
    Sansano Jugador
    Retorno: void
    ************************************************/
    public void reprobar(Sansano Jugador){
        int currentPrioridad = Jugador.getPriori();
        currentPrioridad= currentPrioridad-ataque; 
        Jugador.setPriori(currentPrioridad);       
    }
    
    /**** Getter and setter ****/
    
    /******** Funcion: setAtaque ********************
    Descripcion: le asigna el valor de ataque a la carta
    Parametros:
    int atack
    Retorno: void
    ************************************************/
    public void setAtaque(int atack){
        ataque=atack;
    }
    
    /******** Funcion: getAtaque ********************
    Descripcion: obtiene el valor de ataque de la carta
    Parametros:
    Retorno: int, el valor de ataque de la carta
    ************************************************/
    public int getAtaque(){
        return ataque;
    }
    
    /******** Funcion: setDefensa ********************
    Descripcion: le asigna el valor de defensa a la carta
    Parametros:
    inr def
    Retorno: void
    ************************************************/
    public void setDefensa(int def){
        defensa=def;
    }
    
    /******** Funcion: getDefensa ********************
    Descripcion: obtiene el valor de defensa de la carta
    Parametros:
    Retorno: int, el valor de defensa de la carta
    ************************************************/
    public int getDefensa(){
        return defensa;
    }
    
    @Override
    /******** Funcion: Activar ********************
    Descripcion: activa la carta, ejecutando su habilidad de aprobar
    Parametros:
    Sansano Objetivo
    Retorno: void
    ************************************************/
    public void Activar(Sansano Objetivo){
        aprobar(Objetivo);
    }
    
    @Override
    /******** Funcion: Activar ********************
    Descripcion: activa la carta, ejecutando su habilidad de reprobar. Mismo nombre que la anterior, 
    *            el parametro int marca determina cuando ejecutar una u otra dependiendo de lo que 
    *            elija el jugador.  
    Parametros:
    Sansano Objetivo
    int marca
    Retorno: void
    ************************************************/
    public void Activar(Sansano Objetivo, int marca){
        reprobar(Objetivo);
    }


}
