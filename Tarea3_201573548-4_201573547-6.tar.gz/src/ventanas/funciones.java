package ventanas;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dmede_000
 */
public class funciones {
    public funciones(){
    }
    
    /******** Funcion: random ********************
    Descripcion: entrega un numero(int) al azar dentro de un conjunto de numeros que define el usuario
    *            el valor de retorno pertenece al conjunto [ini,fin[ .
    Parametros:
    int ini
    int fin
    Retorno: int, el numero al azar
    ************************************************/
    public static int random(int ini, int fin){
        int rand;
        rand = ThreadLocalRandom.current().nextInt(ini,fin);
        return rand;
    }
    
    /******** Funcion: CrearCarta ********************
    Descripcion: crea un carta, ya se de tipo Curso, Profesor o Carrete dependiendo del parametro que se le entregue.
    Parametros:
    int numero
    Retorno: Carta, retorna la carta que se desea crear
    ************************************************/
    public static Carta CrearCarta(int numero){
        switch (numero) {
            case 0:
                Curso Mate = new Curso();
                Mate.setNombre("Matematicas");
                Mate.setDescripcion("1");
                Mate.setAtaque(550);
                Mate.setDefensa(200);
                return Mate;
            case 1:
                Curso Fisica = new Curso();
                Fisica.setNombre("Fisica");
                Fisica.setDescripcion("1");
                Fisica.setAtaque(450);
                Fisica.setDefensa(150);
                return Fisica;
            case 2:
                Curso LP = new Curso();
                LP.setNombre("L.d.Programacion");
                LP.setDescripcion("1");
                LP.setAtaque(510);
                LP.setDefensa(180);
                return LP;
            case 3:
                Curso Progra = new Curso();
                Progra.setNombre("Programacion");
                Progra.setDescripcion("1");
                Progra.setAtaque(110);
                Progra.setDefensa(300);
                return Progra;
            case 4:
                Curso ED = new Curso();
                ED.setNombre("E.Discretas");
                ED.setDescripcion("1");
                ED.setAtaque(470);
                ED.setDefensa(160);
                return ED;
            case 5:
                Curso EDD = new Curso();
                EDD.setNombre("E.d.Datos");
                EDD.setDescripcion("1");
                EDD.setAtaque(430);
                EDD.setDefensa(120);
                return EDD;
            case 6:
                Profesor Bah = new Profesor();
                Bah.setNombre("Bahamondes");
                Bah.setDescripcion("2");
                Bah.setDanio(420);
                return Bah;
            case 7:
                Profesor Max = new Profesor();
                Max.setNombre("MaxAraya");
                Max.setDescripcion("2");
                Max.setDanio(350);
                return Max;
            case 8:
                Profesor Cifu = new Profesor();
                Cifu.setNombre("Cifuentes");
                Cifu.setDescripcion("2");
                Cifu.setDanio(390);
                return Cifu;
            case 9:
                Profesor maxR = new Profesor();
                maxR.setNombre("MaxRivera");
                maxR.setDescripcion("2");
                maxR.setDanio(280);
                return maxR;
            case 10:
                Carrete cerrito = new Carrete();
                cerrito.setNombre("Cerrito");
                cerrito.setDescripcion("3");
                cerrito.setCuracion(55);        
                return cerrito;
            case 11:
                Carrete inter = new Carrete();
                inter.setNombre("InterMechon");
                inter.setDescripcion("3");
                inter.setCuracion(80);
                return inter;
            case 12:
                Carrete sansafonda = new Carrete();
                sansafonda.setNombre("Sansafonda");
                sansafonda.setDescripcion("3");
                sansafonda.setCuracion(150);
                return sansafonda;
            case 13:
                Carrete SemanaSansana = new Carrete();
                SemanaSansana.setNombre("Semana Sansana");
                SemanaSansana.setDescripcion("3");
                SemanaSansana.setCuracion(150);
                return SemanaSansana;
            case 14:
                Carrete blibre = new Carrete();
                blibre.setNombre("Bloque Libre");
                blibre.setDescripcion("3");
                blibre.setCuracion(30);
                return blibre;
            case 15:
                Carrete fOmbligo = new Carrete();
                fOmbligo.setNombre("Fiesta Ombligo");
                fOmbligo.setDescripcion("3");
                fOmbligo.setCuracion(125);
                return fOmbligo;
            default:
                return null;
        }
    }
    
    /******** Funcion: crearMazo ********************
    Descripcion: crea un mazo ordenado al azar de tipo ArrayList que contiene elementos de tipo Carta
    Parametros:
    Sansano player
    Retorno: List Carta, retorna el mazo ordenado al azar
    ************************************************/
    public static List<Carta> crearMazo(Sansano player){
        List<Carta> mazo;
        mazo = new ArrayList();
        int array[]={1,4,2,6,3,4,1,1,1,1,1,1,1,1,1,1};
        int i=0;
        while(i<30){
            int rand = random(0,16);
            if(array[rand]!=0){
                if(rand<6){
                    Carta newCarta;
                    newCarta=CrearCarta(rand);
                    mazo.add(newCarta);
                    array[rand]--;
                    i++;  
                }
                else if(rand<10){
                    Carta newCarta;
                    newCarta=CrearCarta(rand);
                    mazo.add(newCarta);                   
                    array[rand]--;
                    i++;
                }
                else{
                    Carta newCarta;
                    newCarta=CrearCarta(rand);
                    mazo.add(newCarta);              
                    array[rand]--;
                    i++;
                }
            }
            
        }
        player.setMazo(mazo);
        return mazo;
    }
    
    /******** Funcion: mazoAgresivo ********************
    Descripcion: crea un mazo de tipo Agresivo(cartas tipo Curso ordenadas de mayor a menor en ataque).
    *            La cartas de tipo Profesor y Carrete están ordenadas al azar
    Parametros:
    Sansano computadora
    Retorno: void
    ************************************************/
    public static void mazoAgresivo(Sansano computadora){
        List<Carta> mazoagr = new ArrayList();
        computadora.setNombre("Oponente");
        computadora.setPriori(3000);
        int i;
        for(i=0;i<20;i++){
            if(i==0){
                Carta newCarta;
                newCarta=CrearCarta(0);
                mazoagr.add(newCarta);
            }
            else if(i<3){
                Carta newCarta;
                newCarta=CrearCarta(2);
                mazoagr.add(newCarta);
            }
            else if(i<6){
                Carta newCarta;
                newCarta=CrearCarta(4);
                mazoagr.add(newCarta);
            }
            else if(i<10){
                Carta newCarta;
                newCarta=CrearCarta(2);
                mazoagr.add(newCarta);
            }
            else if(i<14){
                Carta newCarta;
                newCarta=CrearCarta(5);
                mazoagr.add(newCarta);
            }
            else{
                Carta newCarta;
                newCarta=CrearCarta(3);
                mazoagr.add(newCarta);
            }
        }
        int array[]={1,1,1,1,1,1,1,1,1,1};
        while(i<30){
            int rand = random(6,16);
            if(array[rand-6]!=0){
                if(rand<10){
                    Carta newCarta;
                    newCarta=CrearCarta(rand);
                    mazoagr.add(newCarta);
                    array[rand-6]--;
                    i++;
                }
                else{
                    Carta newCarta;
                    newCarta=CrearCarta(rand);
                    mazoagr.add(newCarta);
                    array[rand-6]--;
                    i++;
                }
            }
        }
    computadora.setMazo(mazoagr);    
    }
    
    /******** Funcion: mazoDefensivo ********************
    Descripcion: crea un mazo de tipo Defensivo(cartas tipo Curso ordenadas de mayor a menor en defensa).
    *            La cartas de tipo Profesor y Carrete están ordenadas al azar
    Parametros:
    Sansano computadora
    Retorno: void
    ************************************************/
    public static void  mazoDefensivo(Sansano computadora){
        List<Carta> mazodef = new ArrayList();
        //Sansano computadora = new Sansano();
        computadora.setNombre("Oponente");
        computadora.setPriori(3000);
        
        int i;
        for(i=0;i<20;i++){
            if(i<6){
                Carta newCarta;
                newCarta=CrearCarta(3);
                mazodef.add(newCarta);
            }
            else if(i==6){
                Carta newCarta;
                newCarta=CrearCarta(0);
                mazodef.add(newCarta);
            }
            else if(i<9){
                Carta newCarta;
                newCarta=CrearCarta(2);
                mazodef.add(newCarta);
            }
            else if(i<12){
                Carta newCarta;
                newCarta=CrearCarta(4);
                mazodef.add(newCarta);
            }
            else if(i<16){
                Carta newCarta;
                newCarta=CrearCarta(1);
                mazodef.add(newCarta);
            }
            else{
                Carta newCarta;
                newCarta=CrearCarta(5);
                mazodef.add(newCarta);
            }
        }
        int array[]={1,1,1,1,1,1,1,1,1,1};
        while(i<30){
            int rand = random(6,16);
            if(array[rand-6]!=0){
                if(rand<10){
                    Carta newCarta;
                    newCarta=CrearCarta(rand);
                    mazodef.add(newCarta);
                    array[rand-6]--;
                    i++;
                }
                else{
                    Carta newCarta;
                    newCarta=CrearCarta(rand);
                    mazodef.add(newCarta);
                    array[rand-6]--;
                    i++;
                }
            }
        }
    computadora.setMazo(mazodef);
    }
    
    /******** Funcion: crearSansano ********************
    Descripcion: crea un jugador de tipo Sansano, inicianizandolo de acuerdo a su nombre.
    *            Le otorga una prioridad inicial de 3000
    Parametros:
    String nombre
    Retorno: Sansano, retorna el sansano creado
    ************************************************/
    public static Sansano crearSansano(String nombre){
        Sansano player = new Sansano();
        player.setNombre(nombre);
        player.setPriori(3000);
        return player;
    }
    
    /******** Funcion: verificarFin ********************
    Descripcion: verifica que el juego no haya terminado.
    *            El juego termina si se acaban las cartas o si una prioridad llega a 0.
    *            Si el juego termina, se guardan los datos y se muestra el resultado final
    Parametros:
    Sansano J1, Sansano J2, Duelo datos
    Retorno: int, 1 si el juego termino, 0 si aun no termina
    ************************************************/
    public static int verificarFin(Sansano J1, Sansano J2, Duelo datos){
        if((J1.getMazo()).isEmpty() || (J2.getMazo()).isEmpty()){
            if(J1.getPriori() > J2.getPriori()){
                datos.setWin(J1);
                new Victoria(datos).setVisible(true);
                return 1;
            }
            else{
                datos.setWin(J2);
                if("Oponente".equals(J2.getNombre())){
                    new Defeat(datos).setVisible(true);
                    return 1;
                }
                else{
                    new Victoria(datos).setVisible(true);
                    return 1;
                }
            }
        }
        if( J1.getPriori() <= 0){
            datos.setWin(J2);
            if("Oponente".equals(J2.getNombre())){
                new Defeat(datos).setVisible(true);
                return 1;
            }
            else{
                new Victoria(datos).setVisible(true);
                return 1;
            }
        }
        else if(J2.getPriori() <= 0){
            datos.setWin(J1);
            new Victoria(datos).setVisible(true);
            return 1;
        }
        return 0;
    } 
    
    
}
