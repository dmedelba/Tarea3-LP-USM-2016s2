package ventanas;


import java.util.List;

public class Sansano {
    
    private String Nombre;
    private int Prioridad;
    /*List<Carta> mazo = new ArrayList();*/
    private List<Carta> Mazo;

    
    public Sansano(){
    };
    /*private class Mazo;*//*Debo definir mazo*/
    public Sansano(String nombre, int prioridad){
        Nombre=nombre;
        Prioridad=prioridad;
    }
    
    /******** Funcion: setNombre ********************
    Descripcion: le asigna el nombre al jugador objetivo
    Parametros:
    String nameJugador
    Retorno: void
    ************************************************/
    public void setNombre(String nameJugador){
        Nombre= nameJugador;
    }
    
    /******** Funcion: getNombre ********************
    Descripcion: obtiene el nombre del jugador objetivo
    Parametros:
    Retorno: String, retorna el nombre del jugador objetivo
    ************************************************/
    public String getNombre(){
        return Nombre;   
    }
    
    /******** Funcion: getPriori ********************
    Descripcion: obtiene la prioridad del jugador objetivo
    Parametros:
    Retorno: int, la prioridad que posee el jugador objetivo
    ************************************************/
    public int getPriori(){
        return Prioridad;
    }
    
    /******** Funcion: setPriori ********************
    Descripcion: le asigna la prioridad(vida) al jugador, si esta es mayor a 3000,
    *            la deja en 3000, y si es menor a 0, la deja en 0.
    Parametros:
    int priori
    Retorno: void
    ************************************************/
    public void setPriori(int priori){
        Prioridad=priori;
        if(Prioridad>3000){
            Prioridad=3000;
        }
        if(Prioridad<0){
            Prioridad=0;
        }
    }
    
    /******** Funcion: getMazo ********************
    Descripcion: obtiene el mazo del jugador objetivo
    Parametros:
    Retorno: List Carta, retorna el mazo(ArrayList) del jugador 
    ************************************************/
    public List<Carta> getMazo(){
        return Mazo;
    }
    
    /******** Funcion: setMazo ********************
    Descripcion: le asigna el mazo al jugador objetivo
    Parametros:
    List Carta mazo 
    Retorno: void
    ************************************************/
    public void setMazo(List<Carta> mazo){
        Mazo=mazo;
    }
    
    
}
