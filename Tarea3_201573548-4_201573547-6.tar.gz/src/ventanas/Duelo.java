package ventanas;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dmede_000
 */
public class Duelo {
    private int cantTurnos;
    private Sansano Ganador;
    
    public Duelo(){
    }
    
    /******** Funcion: getDuelos ********************
    Descripcion: obtiene la cantidad de turnos del juego
    Parametros:
    Retorno: int, el numero de turnos
    ************************************************/
    public int getDuelos(){
        return cantTurnos;
    }
    
    /******** Funcion: setDuelos ********************
    Descripcion: asigna la cantidad de turnos que lleva el juego
    Parametros:
    int nDuelo
    Retorno: void
    ************************************************/
    public void setDuelos(int nDuelo){
        cantTurnos= nDuelo;
    }
    
    /******** Funcion: getWin ********************
    Descripcion: obtiene el nombre del ganador del juego
    Parametros:
    Retorno: String, el nombre del ganador
    ************************************************/
    public Sansano getWin(){
        return Ganador;
    }
    
    /******** Funcion: setWin ********************
    Descripcion: asigna el nombre del ganador del juego
    Parametros:
    String name
    Retorno: void
    ************************************************/
    public void setWin(Sansano name){
        Ganador=name;
        
    }
}
