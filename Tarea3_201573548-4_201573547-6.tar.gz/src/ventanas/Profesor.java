package ventanas;


import ventanas.Sansano;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dmede_000
 */
class Profesor extends Carta{
    int danio;
    
    /******** Funcion: recorregir ********************
    Descripcion: autoinflinge daño al jugador objetivo, actualizandole la prioridad
    Parametros:
    Sansano Objetivo
    Retorno: void
    ************************************************/
    public void recorregir(Sansano Objetivo){
        int currentPrioridad = Objetivo.getPriori();
        currentPrioridad = currentPrioridad-danio;
        Objetivo.setPriori(currentPrioridad);
    }
    
    /**** Getter and setter ****/
    
    /******** Funcion: setDanio ********************
    Descripcion: asigna el danio que posee la carta
    Parametros:
    int danio
    Retorno: void
    ************************************************/
    public void setDanio(int dano){
        danio=dano; 
    }
    
    /******** Funcion: getDanio ********************
    Descripcion: obtiene el valor de danio de la carta
    Parametros:
    Retorno: int, retorna el valor de danio de la carta
    ************************************************/
    public int getDanio(){
        return danio;
    }
    
    
    
    @Override
    /******** Funcion: Activar ********************
    Descripcion: activa la carta, es decir, ejecuta su efecto(llamando a recorregir)
    Parametros:
    Sansano Objetivo
    Retorno: void
    ************************************************/
    public void Activar(Sansano Objetivo){
        recorregir(Objetivo);
        //actualizar interfaz
    }
    
    @Override
    /******** Funcion: Activar ********************
    Descripcion: activa la carta, es decir, ejecuta su efecto(llamando a recorregir)
    *            Hace exactamente lo mismo que la anterior, no tiene mayor efecto.
    Parametros:
    Sansano Objetivo, int marca
    Retorno: void
    ************************************************/
    public void Activar(Sansano Objetivo, int marca){
        recorregir(Objetivo);
    }
    
}
